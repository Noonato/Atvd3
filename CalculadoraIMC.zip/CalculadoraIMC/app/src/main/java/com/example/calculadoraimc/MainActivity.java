package com.example.calculadoraimc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void btnCalcularOnClick(View v) {

        TextView lblResultado = (TextView) findViewById(R.id.lblResultado);
        EditText txtPeso = (EditText) findViewById(R.id.txtPeso);
        EditText txtAltura = (EditText) findViewById(R.id.txtAltura);

        int peso = Integer.parseInt(txtPeso.getText().toString());
        float altura = Float.parseFloat(txtAltura.getText().toString());

        float resultado = peso / (altura * altura);
        if (resultado < 16) {

            lblResultado.setText("Magreza grave!");
        } else if (resultado 16 < 17){

            lblResultado.setText("Magreza Moderada!");
        }
         else if (resultado 17 < 18.5){

            lblResultado.setText("Magreza Leve!");
        }
         else if (resultado 18.5 < 25){

            lblResultado.setText("Saudável!");
        }
         else if (resultado 25 < 30){

            lblResultado.setText("Sobrepeso!");
        }
         else if (resultado 30 < 35){

            lblResultado.setText("Obesidade Grau 1!");
        }
         else if (resultado 35 < 40){

            lblResultado.setText("Obesidade grau 2!");
        }
         else if (resultado >= 40) {

            lblResultado.setText("Obesidade grau 3!(Mórbida)");
        else{
                lblResultado.setText("Peso ok!");
            }
        }
    }
